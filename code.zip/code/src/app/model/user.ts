export class User {
    username: String;
    status: boolean;
    point: number;
}

export class Userprimarymapping {
    username: String;
    primaryImg: String;
    secondaryImg: String;
}

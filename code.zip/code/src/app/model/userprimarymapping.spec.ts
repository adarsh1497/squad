import { Userprimarymapping } from './userprimarymapping';

describe('Userprimarymapping', () => {
  it('should create an instance', () => {
    expect(new Userprimarymapping()).toBeTruthy();
  });
});

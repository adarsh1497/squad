export class Images {
    id: number;
    images: String;
}

import { Images } from './images';

describe('Images', () => {
  it('should create an instance', () => {
    expect(new Images()).toBeTruthy();
  });
});

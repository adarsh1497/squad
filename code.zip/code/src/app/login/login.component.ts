import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { User } from '../model/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User = new User();
  username: String;
  constructor(private registerService: RegisterService) { }

  ngOnInit() {
  }

  submit(){
    //alert('yay!  ' + this.username);
    this.user.point = 0;
    this.user.status = false;
    this.registerService.registerUser(this.user).subscribe(data => console.log(data), err => console.log(err));
  }

}

import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { User } from './model/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient) { }

  registerUser(user: User):Observable<User>{
    alert('in service ' + user.username + ' ' + user.point + ' ' + user.status);
    return this.http.post<User>('http://localhost:1234', user);
  }

}
